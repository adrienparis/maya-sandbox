def plop():
    print("plop")